import tkinter as tk
import threading
import pyautogui
import time
import random

running = False
thread = None

def anti_afk():
    global running
    while running:
        pyautogui.moveRel(random.randint(-3, 3), random.randint(-3, 3), duration=0.1)
        pyautogui.press('space')
        print("Pressed SPACE")
        time.sleep(random.randint(30, 60))

def toggle_anti_afk():
    global running, thread
    if not running:
        running = True
        start_button.config(text="Stop")
        thread = threading.Thread(target=anti_afk, daemon=True)
        thread.start()
    else:
        running = False
        start_button.config(text="Start")

# GUI setup
root = tk.Tk()
root.title("Roblox Anti-AFK")
root.geometry("300x180")
root.resizable(False, False)

# Title label
title = tk.Label(root, text="Anti-AFK for Roblox", font=("Arial", 16, "bold"))
title.pack(pady=20)

# Start/Stop button
start_button = tk.Button(root, text="Start", font=("Arial", 14), width=10, command=toggle_anti_afk)
start_button.pack()

# Handle window close
def on_close():
    global running
    running = False
    root.destroy()

root.protocol("WM_DELETE_WINDOW", on_close)
root.mainloop()
